<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('ci_documents', function (Blueprint $table) {
            $table->id();
            $table->foreignId('profile_id')->constrained('profiles')->cascadeOnDelete();
            $table->string('ci_number', 20)->unique();

            $table->string('front_image')->nullable();
            $table->date('issued_at')->nullable();
            $table->date('expires_at')->nullable();

            $table->boolean('approved')->default(false);
            $table->boolean('status')->default(false);
            $table->timestamps();

            $table->unique(['profile_id']); // 1 CI por perfil
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('ci_documents');
    }
};


